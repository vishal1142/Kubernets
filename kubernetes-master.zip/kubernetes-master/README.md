# kubernetes

## emphiramal containers 


## ingress 

https://kubernetes.io/docs/concepts/services-networking/ingress/

## kubernetes commands link

https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands#create
